// References
// https://github.com/socketio/chat-example/blob/master/index.js


const express = require("express");
const http = require("http");
const app = express();
const server = http.createServer(app);
const socket = require("socket.io");
const io = socket(server);

io.on("connection", socket => {
    socket.emit("your id", socket.id);
    console.log(socket.id);
    
    socket.on("send message", body => {
        io.emit("message", body)
    })
})


server.listen(3001, () => console.log("server is running on port 3001"));