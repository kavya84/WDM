<?php $__env->startComponent('mail::message'); ?>

Welcome <?php echo e($mailData['name']); ?>,

<b>You have been registered with us.</b>
<br>
<h5>Your userid is <?php echo e($mailData['userid']); ?></h5>
<h5>Password is <?php echo e($mailData['pwd']); ?></h5>
<br>
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel8/resources/views/mailtemplate.blade.php ENDPATH**/ ?>