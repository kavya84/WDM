<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\VisitorController;
use App\Http\Controllers\BuildingController;
use App\Http\Controllers\ResidentController;
use App\Http\Controllers\ApartmentController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\GardenController;
use App\Http\Controllers\PoolController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/dashboard',[UsersController::class,'dashboard']);

//users 
Route::get('/users',[UsersController::class,'index']);
Route::post('/users',[UsersController::class,'store']);
Route::post('/users/validate',[UsersController::class,'validateuser']);
Route::get('/users/{userid}',[UsersController::class,'show']);
Route::delete('/users/{userid}',[UsersController::class,'destroy']);

//managers
Route::get('/managers',[ManagerController::class,'index']);
Route::post('/managers',[ManagerController::class,'store']);
Route::get('/managers/{id}',[ManagerController::class,'show']);
Route::delete('/managers/{id}',[ManagerController::class,'destroy']);
Route::put('/managers/{id}',[ManagerController::class,'update']);

//visitors
Route::get('/visitors',[VisitorController::class,'index']);
Route::get('/myvisitors/{id}',[VisitorController::class,'myvisitors']);
Route::post('/visitors',[VisitorController::class,'store']);
Route::get('/visitors/{id}',[VisitorController::class,'show']);
Route::delete('/visitors/{id}',[VisitorController::class,'destroy']);
Route::put('/visitors/{id}',[VisitorController::class,'update']);

//buildings
Route::get('/buildings',[BuildingController::class,'index']);
Route::post('/buildings',[BuildingController::class,'store']);
Route::get('/buildings/{id}',[BuildingController::class,'show']);
Route::delete('/buildings/{id}',[BuildingController::class,'destroy']);
Route::put('/buildings/{id}',[BuildingController::class,'update']);

//residents
Route::get('/residents',[ResidentController::class,'index']);
Route::post('/residents',[ResidentController::class,'store']);
Route::get('/residents/{id}',[ResidentController::class,'show'])->where('id', '[0-9]+');
Route::delete('/residents/{id}',[ResidentController::class,'destroy']);
Route::put('/residents/{id}',[ResidentController::class,'update']);
Route::get('/residents/images',[ResidentController::class,'images']);
Route::post('/residents/upload',[ResidentController::class,'upload']);

//apartments
Route::get('/apartments',[ApartmentController::class,'index']);
Route::post('/apartments',[ApartmentController::class,'store']);
Route::get('/apartments/{id}',[ApartmentController::class,'show']);
Route::delete('/apartments/{id}',[ApartmentController::class,'destroy']);
Route::put('/apartments/{id}',[ApartmentController::class,'update']);

//services
Route::get('/services',[ServiceController::class,'index']);
Route::get('/myservices/{id}',[ServiceController::class,'myservices']);
Route::post('/services',[ServiceController::class,'store']);
Route::get('/services/{id}',[ServiceController::class,'show']);
Route::delete('/services/{id}',[ServiceController::class,'destroy']);
Route::put('/services/{id}',[ServiceController::class,'update']);
Route::get('/reports',[ServiceController::class,'chartData']);

//gardens
Route::get('/gardens',[GardenController::class,'index']);
Route::post('/gardens',[GardenController::class,'store']);
Route::get('/gardens/{id}',[GardenController::class,'show']);
Route::delete('/gardens/{id}',[GardenController::class,'destroy']);
Route::put('/gardens/{id}',[GardenController::class,'update']);

//pools
Route::get('/pools',[PoolController::class,'index']);
Route::post('/pools',[PoolController::class,'store']);
Route::get('/pools/{id}',[PoolController::class,'show']);
Route::delete('/pools/{id}',[PoolController::class,'destroy']);
Route::put('/pools/{id}',[PoolController::class,'update']);