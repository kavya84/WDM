<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pool;

class PoolController extends Controller
{
    public function index()
    {
        return Pool::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'opentime'=>'required',
            'closetime'=>'required',
            'lastclean'=>'required',
            'nextclean'=>'required',
            'mpersonid'=>'required',
            'id'=>'required'
        ]);

        $pool = new Pool([
            'opentime' => $request->get('opentime'),
            'closetime' => $request->get('closetime'),
            'lastclean' => $request->get('lastclean'),
            'nextclean' => $request->get('nextclean'),
            'mpersonid' => $request->get('mpersonid'),
            'id' => $request->get('id')
        ]);
        $pool->save();
        return response()->json([
            "success" => "Pool added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Pool::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Pool::where('id',$id )->first();
        $request->validate([
            'opentime'=>'required',
            'closetime'=>'required',
            'lastclean'=>'required'
        ]);
        $result->update(['opentime'=>$request->get('opentime'),
            'nextclean' => $request->get('nextclean'),
            'mpersonid' => $request->get('mpersonid'),
            'closetime'=>$request->get('closetime'),'lastclean'=>$request->get('lastclean')]);
        return response()->json(['success'=>'Pool updated']);
    }

    public function destroy($pool)
    {
        $pool = Pool::find($pool);
        $pool->delete();
        return response()->json(['success'=>'Pool Deleted successfully']);
    }
}
