<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Apartment;

class ApartmentController extends Controller
{
    public function index()
    {
        return Apartment::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'noofbeds'=>'required',
            'noofbaths'=>'required',
            'totalsqft'=>'required',
            'gas'=>'required',
            'electricity'=>'required',
            'water'=>'required',
            'homeass'=>'required',
            'parkingid'=>'required',
            'bno'=>'required',
            'id'=>'required'
        ]);

        $apartment = new Apartment([
            'noofbeds' => $request->get('noofbeds'),
            'noofbaths' => $request->get('noofbaths'),
            'totalsqft' => $request->get('totalsqft'),
            'gas' => $request->get('gas'),
            'electricity' => $request->get('electricity'),
            'water' => $request->get('water'),
            'homeass' => $request->get('homeass'),
            'parkingid' => $request->get('parkingid'),
            'bno' => $request->get('bno'),
            'id' => $request->get('id')
        ]);
        $apartment->save();
        return response()->json([
            "success" => "Apartment added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Apartment::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Apartment::where('id',$id )->first();
        $request->validate([
            'noofbeds'=>'required',
            'noofbaths'=>'required',
            'totalsqft'=>'required',
            'gas'=>'required',
            'electricity'=>'required',
            'water'=>'required',
            'homeass'=>'required',
            'parkingid'=>'required',
            'bno'=>'required'
        ]);
        $result->update(['noofbeds'=>$request->get('noofbeds'),
            'noofbaths' => $request->get('noofbaths'),
            'totalsqft' => $request->get('totalsqft'),
            'gas' => $request->get('gas'),
            'electricity' => $request->get('electricity'),
            'water' => $request->get('water'),
            'homeass' => $request->get('homeass'),
            'parkingid' => $request->get('parkingid'),
            'bno' => $request->get('bno')
        ]);
        return response()->json(['success'=>'Apartment updated']);
    }

    public function destroy($id)
    {
        $apartment = Apartment::find($id);
        $apartment->delete();
        return response()->json(['success'=>'Apartment Deleted successfully']);
    }
}
