<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use Illuminate\Support\Facades\DB;

class ServiceController extends Controller
{
    public function index()
    {
        return Service::all();
    }

    public function chartData(){
        return DB::table('services')
            ->select('userid', DB::raw('count(*) as total'))
            ->groupBy('userid')
            ->get();
    }

    public function myservices($id)
    {
        return Service::where('userid',$id)->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'descr'=>'required',
            'priority'=>'required',
            'apartment'=>'required',
            'building'=>'required',
            'mpersonid'=>'required',
            'status'=>'required',
            'id'=>'required'
        ]);

        $service = new Service([
            'descr' => $request->get('descr'),
            'priority' => $request->get('priority'),
            'apartment' => $request->get('apartment'),
            'building' => $request->get('building'),
            'mpersonid' => $request->get('mpersonid'),
            'status' => $request->get('status'),
            'userid' => $request->get('userid'),
            'id' => $request->get('id')
        ]);
        $service->save();
        return response()->json([
            "success" => "Service added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Service::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Service::where('id',$id )->first();
        $request->validate([
            'descr'=>'required',
            'priority'=>'required',
            'apartment'=>'required',
            'building'=>'required',
            'mpersonid'=>'required',
            'status'=>'required',
        ]);
        $result->update([
            'descr' => $request->get('descr'),
            'priority' => $request->get('priority'),
            'apartment' => $request->get('apartment'),
            'building' => $request->get('building'),
            'mpersonid' => $request->get('mpersonid'),
            'status' => $request->get('status')
        ]);
        return response()->json(['success'=>'Service updated']);
    }

    public function destroy($id)
    {
        $service = Service::find($id);
        $service->delete();
        return response()->json(['success'=>'Service Deleted successfully']);
    }
}
