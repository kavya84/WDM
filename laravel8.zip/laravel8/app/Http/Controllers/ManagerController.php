<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Manager;

class ManagerController extends Controller
{
    public function index()
    {
        return Manager::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'id'=>'required'
        ]);

        $mgr = new Manager([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'id' => $request->get('id')
        ]);
        $mgr->save();
        return response()->json([
            "success" => "Manager added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Manager::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Manager::where('id',$id )->first();
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required'
        ]);
        $result->update(['name'=>$request->get('name'),'email'=>$request->get('email'),'phone'=>$request->get('phone')]);
        return response()->json(['success'=>'Manager updated']);
    }

    public function destroy($mgrid)
    {
        $mgr = Manager::find($mgrid);
        $mgr->delete();
        return response()->json(['success'=>'Manager Deleted successfully']);
    }

}
