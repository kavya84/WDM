<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Garden;

class GardenController extends Controller
{
    public function index()
    {
        return Garden::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'plantname'=>'required',
            'planttype'=>'required',
            'lastmdate'=>'required',
            'plantid'=>'required'
        ]);

        $garden = new Garden([
            'plantname' => $request->get('plantname'),
            'planttype' => $request->get('planttype'),
            'lastmdate' => $request->get('lastmdate'),
            'nextsdate' => $request->get('nextsdate'),
            'mpersonid' => $request->get('mpersonid'),
            'plantid' => $request->get('plantid')
        ]);
        $garden->save();
        return response()->json([
            "success" => "Garden added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Garden::where('plantid',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Garden::where('plantid',$id )->first();
        $request->validate([
            'plantname'=>'required',
            'planttype'=>'required',
            'lastmdate'=>'required'
        ]);
        $result->update([
            'plantname' => $request->get('plantname'),
            'planttype' => $request->get('planttype'),
            'lastmdate' => $request->get('lastmdate'),
            'nextsdate' => $request->get('nextsdate'),
            'mpersonid' => $request->get('mpersonid'),
        ]);
        return response()->json(['success'=>'Garden updated']);
    }

    public function destroy($id)
    {
        $garden = Garden::find($id);
        $garden->delete();
        return response()->json(['success'=>'Garden Deleted successfully']);
    }
}
