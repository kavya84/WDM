<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Mail;
use App\Mail\MyMailer;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    public function index()
    {
        return Users::all();
    }

    public function dashboard()
    {
        $users=DB::table('users')->count();
        $buildings=DB::table('buildings')->count();
        $visitors=DB::table('visitors')->count();
        $managers=DB::table('managers')->count();
        $gardens=DB::table('gardens')->count();
        $pools=DB::table('pools')->count();
        $residents=DB::table('residents')->count();
        $apartments=DB::table('apartments')->count();
        $services=DB::table('services')->count();
        return get_defined_vars();
    }

    public function validateuser(Request $request)
    {
        $request->validate([
            'userid'=>'required',
            'pwd'=>'required'
        ]);

        $userid=$request->get("userid");
        $pwd=$request->get("pwd");

        $result = Users::where('userid',$userid )->where('pwd',$pwd)->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
      }
    }

    public function store(Request $request)
    {
        $request->validate([
            'uname'=>'required',
            'userid'=>'required',
            'phone'=>'required',
            'role'=>'required',
            'pwd'=>'required'
        ]);

        $user = new Users([
            'uname' => $request->get('uname'),
            'userid' => $request->get('userid'),
            'phone' => $request->get('phone'),
            'pwd' => $request->get('pwd'),
            'role' => $request->get('role')
        ]);
        $user->save();
        $mailData=[
            'userid'=>$request->get('userid'),
            'name'=>$request->get('uname'),
            'pwd'=>$request->get('pwd')
        ];
        
  //      Mail::to($request->get('userid'))->send(new MyMailer($mailData));
   
        // return response()->json([
        //     'message' => 'Email has been sent.'
        // ], Response::HTTP_OK);

        return response()->json([
            "success" => "User registered successfully"
        ]);
    }

    public function show($userid)
    {
        $result = Users::where('userid',$userid )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        
    }

    public function destroy($userid)
    {
        $user = Users::find($userid);
        $user->delete();
        return response()->json(['success'=>'User Deleted successfully']);
    }
}
