<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Building;

class BuildingController extends Controller
{
    public function index()
    {
        return Building::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'ldate'=>'required',
            'tdate'=>'required',
            'bno'=>'required'
        ]);

        $Building = new Building([
            'laundrydate' => $request->get('ldate'),        
            'trashdate' => $request->get('tdate'),
            'bno' => $request->get('bno')
        ]);
        $Building->save();
        return response()->json([
            "success" => "Building added successfully"
        ]);
    }

    public function show($bno)
    {
        $result = Building::where('bno',$bno )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $bno)
    {
        $result = Building::where('bno',$bno )->first();
        $request->validate([
            'laundrydate'=>'required',
            'trashdate'=>'required'
        ]);
        $result->update(['laundrydate'=>$request->get('laundrydate'),
        'trashdate'=>$request->get('trashdate')
        ]);
        return response()->json(['success'=>'Building updated']);
    }

    public function destroy($bno)
    {
        $Building = Building::find($bno);
        $Building->delete();
        return response()->json(['success'=>'Building Deleted successfully']);
    }
}
