<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Visitor;

class VisitorController extends Controller
{
    public function index()
    {
        return Visitor::all();
    }

    public function myvisitors($id)
    {
        return Visitor::where('userid',$id )->get();
        //return Visitor::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'apartment'=>'required',
            'vehicleno'=>'required',
            'phone'=>'required',
            'id'=>'required'
        ]);

        $visitor = new Visitor([
            'name' => $request->get('name'),
            'apartment' => $request->get('apartment'),
            'vehicleno' => $request->get('vehicleno'),
            'phone' => $request->get('phone'),
            'userid' => $request->get('userid'),
            'id' => $request->get('id')
        ]);
        $visitor->save();
        return response()->json([
            "success" => "Visitor added successfully"
        ]);
    }

    public function show($id)
    {
        $result = Visitor::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Visitor::where('id',$id )->first();
        $request->validate([
            'name'=>'required',
            'vehicleno'=>'required',
            'apartment'=>'required',
            'phone'=>'required'
        ]);
        $result->update(['name'=>$request->get('name'),
        'apartment'=>$request->get('apartment'),
        'vehicleno'=>$request->get('vehicleno'),
        'phone'=>$request->get('phone')]);
        return response()->json(['success'=>'Visitor updated']);
    }

    public function destroy($id)
    {
        $visitor = Visitor::find($id);
        $visitor->delete();
        return response()->json(['success'=>'Visitor Deleted successfully']);
    }
}
