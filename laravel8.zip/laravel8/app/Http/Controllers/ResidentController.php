<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Resident;
use App\Models\Images;

class ResidentController extends Controller
{
    public function images()
    {
        return Images::all();
    }

    public function upload(Request $request)
    {
        if ($file = $request->file('file')) {
            $filename = time().rand(1,10000). '.'.$file->getClientOriginalExtension();
            $file->move('uploads/', $filename);
            
            //store your file into directory and db
            $save = new Images();
            $save->imgName = $filename;
            $save->type=$file->getClientOriginalExtension()!="mp4" ? "Image":"Video";
            $save->save();
              
            return response()->json([
                "success" => true,
                "message" => "File successfully uploaded",
                "file" => $file
            ]);
  
        }
    }

    public function index()
    {
        return Resident::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'apartment'=>'required',
            'vehicleno'=>'required',
            'id'=>'required'
        ]);

        $Resident = new Resident([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'apartment' => $request->get('apartment'),
            'vehicleno' => $request->get('vehicleno'),
            'id' => $request->get('id')
        ]);
        $Resident->save();
        return response()->json($Resident, 201);
    }

    public function show($id)
    {
        $result = Resident::where('id',$id )->first();
        if($result){
         return Response()->json($result);
        }
        else
        {
        return response()->json(['found' => false], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $result = Resident::where('id',$id )->first();
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required'
        ]);
        $result->update(['name'=>$request->get('name'),'email'=>$request->get('email'),'phone'=>$request->get('phone'),'apartment' => $request->get('apartment'),
        'vehicleno' => $request->get('vehicleno')]);
        return response()->json(['success'=>'Resident updated']);
    }

    public function destroy($id)
    {
        $Resident = Resident::find($id);
        $Resident->delete();
        return response()->json(['success'=>'Resident Deleted successfully']);
    }
}
