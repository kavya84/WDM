@component('mail::message')

Welcome {{$mailData['name']}},

<b>You have been registered with us.</b>
<br>
<h5>Your userid is {{$mailData['userid']}}</h5>
<h5>Password is {{$mailData['pwd']}}</h5>
<br>
<br>
Thanks,<br>
{{ config('app.name') }}
@endcomponent
